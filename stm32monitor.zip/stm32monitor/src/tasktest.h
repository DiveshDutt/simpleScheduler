/*
   FILE          : Task_Executive.h
   PROJECT       : Assignment1
   PROGRAMMER    : Divesh Dutt
   FIRST VERSION : 12-Dec-2017
   DESCRIPTION   : Include all the function prototypes
                   that was defined in Task_executive.c
*/


void TaskInit(void);
int32_t TaskAdd(void (*f)(void *data), void *data);
int32_t TaskKill(int32_t id);
int32_t TaskCurrent(void);
int32_t TaskSwitcher(void);
