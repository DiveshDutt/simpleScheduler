/*
   FILE          : tasks.c
   Date 	 : Dec-11-2017  

   PROGRAMMER    : Divesh Dutt
   DESCRIPTION   : It will do many things like TaskAdd(),
                   TaskKill(),TaskCurrent(),TaskSwitcher(),TaskCurrent(),TaskSwitcher() 
*/

//header files  
#include <stdio.h>
#include <stdint.h>
#include "common.h"
#include "tasktest.h"



//MACRO for MAX_TASKS
#define MAX_TASKS 3

typedef struct Task_s 
{
 void (*f)(void *data); // Task function
 void *data;            // Private data pointer for this task 
} Task_t;

// Process list 
Task_t tasks[MAX_TASKS];
int32_t currentTask=20;  //Initial value of currentTask

/*
Function     : TaskAdd() 
Parameter    : function pointer and data pointer
*/ 
int32_t TaskAdd(void (*f)(void *data), void *data)
{
 for(int i=0; i<MAX_TASKS; i++)
 {
  if(tasks[i].f == NULL)        //finds empty slot
  {
   tasks[i].f    = f;      
   tasks[i].data = data;
   return i;
  }
 }
 return -1;
// No slots available, return -1 
}

/*
Function     : TaskKill() 
Description  : Set the function pointer in the array
               entry at passed value equal to NULL.It will
               mark the task as inactive.
Parameters   : None
Returns      : Returns 0
*/ 
int32_t TaskKill(int32_t value)
{
 tasks[value].f    = NULL;      // emptying the slot
 tasks[value].data = NULL;
 return 0;
}


/*
Function     : TaskCurrent() 
Description  : It will find the runnable tasks 
               by examining the entries following 
               the current task in circular order.
Parameters   : None
Returns      : i if count < MAX_TASKS, else -1
*/ 
int32_t TaskCurrent(void)
{
 int32_t i;
 uint32_t count=0;
 i = currentTask;
 do
 {
  i = (i + 1) % MAX_TASKS;
  count++;
 }
 while((tasks[i].f == NULL)&& (count <= MAX_TASKS));
 return (count <= MAX_TASKS) ? i : -1;
}

/*
Function     : TaskSwitcher() 
Description  : It will run all active tasks in sequence
Parameters   : None
Returns      : -1 if currentTask < 0 and 0 on success
*/
int32_t TaskSwitcher(void)
{
currentTask = TaskCurrent();  //assign next task as current task
if(currentTask < 0) 
{
return -1;
}
tasks[currentTask].f(tasks[currentTask].data);
return 0;
}

