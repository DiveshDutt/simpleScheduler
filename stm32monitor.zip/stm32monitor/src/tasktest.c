/*
   FILE          : tasktest.c
   Date 	 : 2017-DEC-12   

   PROGRAMMER    : Divesh Dutt
   DESCRIPTION   : this file include three tasks like addition,
                   multiplication and will print my name on terminal
*/

//Header Files
#include <stdio.h>
#include <stdint.h>
#include "common.h"
#include "tasktest.h"

//Function prototypes
void TaskInit();
void AddTask();
void Task1();
void Task2();
void Task3();


/*
Function     : TaskInit() 
Description  : Initialise the task by initially assigning
               NULL to all the tasks
Parameters   : None
Returns      : None
*/ 
void TaskInit() 
{

  AddTask();   //it will add three tasks 
 
}


/*
Function     : addTask() 
Description  : Add all the tasks to the program
Parameters   : None
Returns      : None
*/ 
void AddTask()
{
 TaskAdd(Task1,NULL);
 TaskAdd(Task2,NULL);
 TaskAdd(Task3,NULL);
 
 printf("Tasks 1,2,3 are added\n");
}


ParserReturnVal_t CmdTaskKill(int mode)
{
int32_t value;
 if(mode != CMD_INTERACTIVE)  // checks the mode value
 {
  return CmdReturnOk;
 }
fetch_int32_arg(&value);
 TaskKill(value);       //kill the task
return CmdReturnOk;
}
 
ADD_CMD("kill",CmdTaskKill,"          kill the Task");

/*
Function     : Task1() 
Description     :It will Multiply two numbers
Parameters   : None
Returns      : None
*/
void Task1()
{
 uint8_t a = 2;
 uint8_t b = 14;
 uint8_t c = a*b;
 printf("Task1 running : Multiplication is= %u\n", c);
}

/*
Function     : Task2() 
Description  : print Name
Parameters   : None
Returns      : None
*/
void Task2()
{
 printf("Task2 running : HI DIVESH\n");
}

/*
Function     : Task3() 
Description  : print addition of two numbers 
Parameters   : None
Returns      : None
*/
void Task3()
{
uint8_t a=8;
uint8_t b=9;
 
printf("Task3 running : Addition is %u\n",a+b);
}
ParserReturnVal_t cmdTaskadd(int mode)
{

 if(mode != CMD_INTERACTIVE)  // checks the mode value
 {
  return CmdReturnOk;
 }
 TaskInit();                  // calls the function 

 return CmdReturnOk;
 }

 
ADD_CMD("taskadd",cmdTaskadd,"                ADD Tasks");

/*
Function     : TaskSwitcher() 
Description  : It will run all active tasks in sequence
Parameters   : None
Returns      : -1 if currentTask<0, else 0 for success
*/
ParserReturnVal_t cmdTaskSwitcher(int mode)
{
 int i;
 if(mode != CMD_INTERACTIVE)  
 {
  return CmdReturnOk;
 }

 for(i=0;i<20;i++)            //it will print the task 20 times in alternate way
 {
  TaskSwitcher();             // it will switch task      
  }
return CmdReturnOk;
 }

 
ADD_CMD("RunTask",cmdTaskSwitcher,"                start executing  Tasks");
